/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     | Website:  https://openfoam.org
    \\  /    A nd           | Copyright (C) YEAR OpenFOAM Foundation
     \\/     M anipulation  |
-------------------------------------------------------------------------------
License
    This file is part of OpenFOAM.

    OpenFOAM is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    OpenFOAM is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with OpenFOAM.  If not, see <http://www.gnu.org/licenses/>.

\*---------------------------------------------------------------------------*/

#include "codedFvModelTemplate.H"
#include "addToRunTimeSelectionTable.H"
#include "volFields.H"
#include "surfaceFields.H"
#include "read.H"
#include "fvMatrix.H"

//{{{ begin codeInclude

//}}} end codeInclude


// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

namespace Foam
{

namespace fv
{

// * * * * * * * * * * * * * * * Local Functions * * * * * * * * * * * * * * //

//{{{ begin localCode

//}}} end localCode


// * * * * * * * * * * * * * * * Global Functions  * * * * * * * * * * * * * //

extern "C"
{
    // dynamicCode:
    // SHA1 = 8583beff53a972fa469c0e507f0174260d67938d
    //
    // unique function name that can be checked if the correct library version
    // has been loaded
    void mmsForce_8583beff53a972fa469c0e507f0174260d67938d(bool load)
    {
        if (load)
        {
            // code that can be explicitly executed after loading
        }
        else
        {
            // code that can be explicitly executed before unloading
        }
    }
}

// * * * * * * * * * * * * * * Static Data Members * * * * * * * * * * * * * //

defineTypeNameAndDebug(mmsForceFvModelvectorSource, 0);

addRemovableToRunTimeSelectionTable
(
    fvModel,
    mmsForceFvModelvectorSource,
    dictionary
);


const char* const mmsForceFvModelvectorSource::SHA1sum =
    "8583beff53a972fa469c0e507f0174260d67938d";


// * * * * * * * * * * * * * * * * Constructors  * * * * * * * * * * * * * * //

mmsForceFvModelvectorSource::
mmsForceFvModelvectorSource
(
    const word& name,
    const word& modelType,
    const fvMesh& mesh,
    const dictionary& dict
)
:
    fvModel(name, modelType, mesh, dict),
    zone_(mesh, coeffs(dict))
{
    if (false)
    {
        Info<<"construct mmsForce sha1: 8583beff53a972fa469c0e507f0174260d67938d"
            " from components\n";
    }
}


// * * * * * * * * * * * * * * * * Destructor  * * * * * * * * * * * * * * * //

mmsForceFvModelvectorSource::
~mmsForceFvModelvectorSource()
{
    if (false)
    {
        Info<<"destroy mmsForce sha1: 8583beff53a972fa469c0e507f0174260d67938d\n";
    }
}


// * * * * * * * * * * * * * * * Member Functions  * * * * * * * * * * * * * //

void mmsForceFvModelvectorSource::addSup
(
    const VolField<vector>& field,
    fvMatrix<vector>& eqn
) const
{
    if (false)
    {
        Info<<"mmsForceFvModelvectorSource::addSup()\n";
    }

//{{{ begin code
    #line 7 "//case/constant/fvModels/mmsForce"

 const scalar viscosity = 0.01;
 const scalar frequency = 4.0;
 const scalar decay = exp(-mesh().time().value());
 if (!mesh().foundObject<volScalarField>("refineSensor")) {
   auto* sensor = new volScalarField(
     IOobject("refineSensor", mesh().time().name(), mesh(), IOobject::NO_READ, IOobject::AUTO_WRITE),
     mesh(), dimensionedScalar("zero", dimless, 0), "cyclic");
   sensor->store();
 }
 volScalarField& sensor = mesh().lookupObjectRef<volScalarField>("refineSensor");
 const vectorField& centers = mesh().C();
 const scalarField& volumes = mesh().V();
 vectorField& source = eqn.source();
 auto gDeriv = [](scalar q, label order) {
   const scalar amplitude[5] = {35,56,28,8,1};
   scalar value = 0;
   for (label mode=0; mode<=4; ++mode) {
     const scalar phase = mode*q + order*constant::mathematical::pi/2;
     value += amplitude[mode]*pow(scalar(mode),order)*cos(phase)/128;
   }
   return value;
 };
 forAll(centers, celli) {
   const scalar x = centers[celli].x();
   const scalar y = centers[celli].y();
   const scalar z = centers[celli].z();
   scalar gy[4], hz[4];
   for (label order=0; order<4; ++order) {
     gy[order] = gDeriv(y, order);
     hz[order] = gDeriv(z, order);
   }
   const scalar chi = gy[0]*hz[0];
   const scalar chiY = gy[1]*hz[0];
   const scalar chiZ = gy[0]*hz[1];
   const scalar chiYY = gy[2]*hz[0];
   const scalar chiZZ = gy[0]*hz[2];
   const scalar chiYZ = gy[1]*hz[1];
   const scalar chiYYY = gy[3]*hz[0];
   const scalar chiYZZ = gy[1]*hz[2];
   const scalar sx = sin(frequency*x), cx = cos(frequency*x);
   sensor[celli] = sqr(decay*chi*sx);
   const vector u(chiY*sx/sqr(frequency), -chi*cx/frequency, 0);
   const scalar duxDx = chiY*cx/frequency;
   const scalar duxDy = chiYY*sx/sqr(frequency);
   const scalar duyDx = chi*sx;
   const scalar duyDy = -chiY*cx/frequency;
   const vector conv(u.x()*duxDx + u.y()*duxDy,
                     u.x()*duyDx + u.y()*duyDy, 0);
   const vector lapU(sx*(-chiY + (chiYYY+chiYZZ)/sqr(frequency)),
                     cx*(frequency*chi - (chiYY+chiZZ)/frequency), 0);
   const vector forcing = -decay*u + sqr(decay)*conv - viscosity*decay*lapU;
   source[celli] -= volumes[celli]*forcing;
 }
 sensor.correctBoundaryConditions();
 
//}}} end code
}


void mmsForceFvModelvectorSource::addSup
(
    const volScalarField& rho,
    const VolField<vector>& field,
    fvMatrix<vector>& eqn
) const
{
    if (false)
    {
        Info<<"mmsForceFvModelvectorSource::addSup()\n";
    }

//{{{ begin code
    
//}}} end code
}


void mmsForceFvModelvectorSource::addSup
(
    const volScalarField& alpha,
    const volScalarField& rho,
    const VolField<vector>& field,
    fvMatrix<vector>& eqn
) const
{
    if (false)
    {
        Info<<"mmsForceFvModelvectorSource::addSup()\n";
    }

//{{{ begin code
    
//}}} end code
}


bool mmsForceFvModelvectorSource::movePoints()
{
    zone_.movePoints();
    return true;
}


void mmsForceFvModelvectorSource::topoChange(const polyTopoChangeMap& map)
{
    zone_.topoChange(map);
}


void mmsForceFvModelvectorSource::mapMesh(const polyMeshMap& map)
{
    zone_.mapMesh(map);
}


void mmsForceFvModelvectorSource::distribute
(
    const polyDistributionMap& map
)
{
    zone_.distribute(map);
}


// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

} // End namespace Foam
} // End namespace fv

// ************************************************************************* //

