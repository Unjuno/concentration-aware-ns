/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     | Website:  https://openfoam.org
    \\  /    A nd           | Copyright (C) YEAR OpenFOAM Foundation
     \\/     M anipulation  |
-------------------------------------------------------------------------------
License
    This file is part of OpenFOAM.

    OpenFOAM is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    OpenFOAM is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with OpenFOAM.  If not, see <http://www.gnu.org/licenses/>.

\*---------------------------------------------------------------------------*/

#include "codedFvModelTemplate.H"
#include "addToRunTimeSelectionTable.H"
#include "volFields.H"
#include "surfaceFields.H"
#include "read.H"
#include "fvMatrix.H"

//{{{ begin codeInclude

//}}} end codeInclude


// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

namespace Foam
{

namespace fv
{

// * * * * * * * * * * * * * * * Local Functions * * * * * * * * * * * * * * //

//{{{ begin localCode

//}}} end localCode


// * * * * * * * * * * * * * * * Global Functions  * * * * * * * * * * * * * //

extern "C"
{
    // dynamicCode:
    // SHA1 = f37238486f93fdadd337d27ed8b1f9f1196d5e64
    //
    // unique function name that can be checked if the correct library version
    // has been loaded
    void mmsForce_f37238486f93fdadd337d27ed8b1f9f1196d5e64(bool load)
    {
        if (load)
        {
            // code that can be explicitly executed after loading
        }
        else
        {
            // code that can be explicitly executed before unloading
        }
    }
}

// * * * * * * * * * * * * * * Static Data Members * * * * * * * * * * * * * //

defineTypeNameAndDebug(mmsForceFvModelvectorSource, 0);

addRemovableToRunTimeSelectionTable
(
    fvModel,
    mmsForceFvModelvectorSource,
    dictionary
);


const char* const mmsForceFvModelvectorSource::SHA1sum =
    "f37238486f93fdadd337d27ed8b1f9f1196d5e64";


// * * * * * * * * * * * * * * * * Constructors  * * * * * * * * * * * * * * //

mmsForceFvModelvectorSource::
mmsForceFvModelvectorSource
(
    const word& name,
    const word& modelType,
    const fvMesh& mesh,
    const dictionary& dict
)
:
    fvModel(name, modelType, mesh, dict),
    zone_(mesh, coeffs(dict))
{
    if (false)
    {
        Info<<"construct mmsForce sha1: f37238486f93fdadd337d27ed8b1f9f1196d5e64"
            " from components\n";
    }
}


// * * * * * * * * * * * * * * * * Destructor  * * * * * * * * * * * * * * * //

mmsForceFvModelvectorSource::
~mmsForceFvModelvectorSource()
{
    if (false)
    {
        Info<<"destroy mmsForce sha1: f37238486f93fdadd337d27ed8b1f9f1196d5e64\n";
    }
}


// * * * * * * * * * * * * * * * Member Functions  * * * * * * * * * * * * * //

void mmsForceFvModelvectorSource::addSup
(
    const VolField<vector>& field,
    fvMatrix<vector>& eqn
) const
{
    if (false)
    {
        Info<<"mmsForceFvModelvectorSource::addSup()\n";
    }

//{{{ begin code
    #line 7 "//case/constant/fvModels/mmsForce"

 const scalar viscosity = 0.01;
 const scalar now = mesh().time().value();
 const scalar scale = exp(-4*viscosity*now);
 const vectorField& centers = mesh().C();
 const scalarField& volumes = mesh().V();
 vectorField& source = eqn.source();
 forAll(centers, celli) {
   const scalar x = centers[celli].x(), y = centers[celli].y(), z = centers[celli].z();
   const scalar sx = sin(x), sy = sin(y), sz = sin(z);
   const scalar cx = cos(x), cy = cos(y), cz = cos(z);
   const vector u0(sx*sz + cx*cy, sy*sx + cy*cz, sz*sy + cz*cx);
   const scalar a00 = cx*sz - sx*cy, a01 = -cx*sy, a02 = sx*cz;
   const scalar a10 = sy*cx, a11 = cy*sx - sy*cz, a12 = -cy*sz;
   const scalar a20 = -cz*sx, a21 = sz*cy, a22 = cz*sy - sz*cx;
   const vector conv(a00*u0.x()+a01*u0.y()+a02*u0.z(),
                     a10*u0.x()+a11*u0.y()+a12*u0.z(),
                     a20*u0.x()+a21*u0.y()+a22*u0.z());
   const vector gradp(
     -(cx*sin(2*y)*cz + 2*cos(2*x)*sz*cy - sy*sin(2*z)*sx)/6,
     -(2*sx*cos(2*y)*cz - sin(2*x)*sz*sy + cy*sin(2*z)*cx)/6,
     -(-sx*sin(2*y)*sz + sin(2*x)*cz*cy + 2*sy*cos(2*z)*cx)/6);
   const vector forcing = scale*(conv + gradp);
   source[celli] -= volumes[celli]*forcing;
 }
 
//}}} end code
}


void mmsForceFvModelvectorSource::addSup
(
    const volScalarField& rho,
    const VolField<vector>& field,
    fvMatrix<vector>& eqn
) const
{
    if (false)
    {
        Info<<"mmsForceFvModelvectorSource::addSup()\n";
    }

//{{{ begin code
    
//}}} end code
}


void mmsForceFvModelvectorSource::addSup
(
    const volScalarField& alpha,
    const volScalarField& rho,
    const VolField<vector>& field,
    fvMatrix<vector>& eqn
) const
{
    if (false)
    {
        Info<<"mmsForceFvModelvectorSource::addSup()\n";
    }

//{{{ begin code
    
//}}} end code
}


bool mmsForceFvModelvectorSource::movePoints()
{
    zone_.movePoints();
    return true;
}


void mmsForceFvModelvectorSource::topoChange(const polyTopoChangeMap& map)
{
    zone_.topoChange(map);
}


void mmsForceFvModelvectorSource::mapMesh(const polyMeshMap& map)
{
    zone_.mapMesh(map);
}


void mmsForceFvModelvectorSource::distribute
(
    const polyDistributionMap& map
)
{
    zone_.distribute(map);
}


// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

} // End namespace Foam
} // End namespace fv

// ************************************************************************* //

